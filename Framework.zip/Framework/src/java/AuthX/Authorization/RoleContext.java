/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AuthX.Authorization;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author krish
 */
public class RoleContext {
    private RoleStrategy strategy;

    public RoleContext(RoleStrategy strategy) {
        this.strategy = strategy;
    }

    public void executeStrategy(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (strategy != null) {
            strategy.redirect(request, response);
        } else {
            response.sendRedirect("AccessDenied");
        }
    }
}


