/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AuthX.Authorization;

/**
 *
 * @author krish
 */
public class StrategyFactory 
{
    public static RoleStrategy getStrategy(String role) {
        if (role == null) return null;

        switch (role) {
            case "Admin":
                return new AdminStrategy();
            case "User":
                return new UserStrategy();
            //Add new cases here.
            default:
                return null;
        }
    }
}
