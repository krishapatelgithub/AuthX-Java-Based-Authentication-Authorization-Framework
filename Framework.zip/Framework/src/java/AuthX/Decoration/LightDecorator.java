/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AuthX.Decoration;

import AuthX.Authentication.IAuth;

/**
 *
 * @author krish
 */
public class LightDecorator extends ComponentDecorator
{
    IAuth a;
    public LightDecorator(IAuth a)
    {
        this.a = a;
    }
    
    public String createComponent()
    {
        String s = a.createComponent();
        return "<style>\n" +
"  body {\n" +
"    background-color: #f3f4f6; /* Light background */\n" +
"    color: #1e1e2f; /* Dark text color */\n" +
"    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n" +
"    display: flex;\n" +
"    justify-content: center;\n" +
"    align-items: center;\n" +
"    height: 100vh;\n" +
"    margin: 0;\n" +
"  }\n" +
"\n" +
"  .form-container {\n" +
"    width: 100%;\n" +
"    max-width: 300px;\n" +
"    padding: 3rem;\n" +
"    padding-right: 4.5rem;\n" +
"  }\n" +
"\n" +
"  form {\n" +
"    background-color: #ffffff; /* White background for the form */\n" +
"    border-radius: 1rem;\n" +
"    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); /* Lighter shadow */\n" +
"  }\n" +
"\n" +
"  label {\n" +
"    color: #1e1e2f; /* Dark label color */\n" +
"    font-weight: 600;\n" +
"    margin-bottom: 0.5rem;\n" +
"  }\n" +
"\n" +
"  input[type=\"text\"],\n" +
"  input[type=\"email\"],\n" +
"  input[type=\"password\"],\n" +
"  select {\n" +
"    width: 100%;\n" +
"    padding: 0.75rem;\n" +
"    background-color: #f9fafb; /* Light input background */\n" +
"    border: 1px solid #d1d5db; /* Light border */\n" +
"    color: #1e1e2f; /* Dark text color */\n" +
"    margin-top: 0.5rem;\n" +
"    margin-bottom: 0.7rem;\n" +
"    border-radius: 0.5rem;\n" +
"    outline: none;\n" +
"  }\n" +
"\n" +
"  input:focus,\n" +
"  select:focus {\n" +
"    border-color: #3b82f6; /* Focus border color */\n" +
"    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5); /* Focus shadow */\n" +
"  }\n" +
"\n" +
"  input[type=\"radio\"],\n" +
"  input[type=\"checkbox\"] {\n" +
"    accent-color: #3b82f6; /* Accent color for radio/checkbox */\n" +
"    height: 1rem;\n" +
"    width: 1rem;\n" +
"  }\n" +
"\n" +
"  .form-radio + span,\n" +
"  .form-checkbox + span {\n" +
"    color: #1e1e2f; /* Dark text color for labels */\n" +
"    margin-left: 0.5rem;\n" +
"  }\n" +
"\n" +
"  button[type=\"submit\"] {\n" +
"    width: 100%;\n" +
"    padding: 0.78rem;\n" +
"    background-color: #3b82f6; /* Button background color */\n" +
"    color: white; /* Button text color */\n" +
"    font-weight: 600;\n" +
"    border-radius: 0.5rem;\n" +
"    border: none;\n" +
"    cursor: pointer;\n" +
"    transition: background-color 0.3s ease;\n" +
"  }\n" +
"\n" +
"  button[type=\"submit\"]:hover {\n" +
"    background-color: #2563eb; /* Darker button color on hover */\n" +
"  }\n" +
"\n" +
"  .mb-4 {\n" +
"    margin-bottom: 1rem;\n" +
"  }\n" +
"</style>" + s;
    }
}
