/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package AuthX.Authentication;

import AuthX.Authorization.RoleContext;
import AuthX.Authorization.RoleStrategy;
import AuthX.Authorization.StrategyFactory;
import AuthX.Session.SessionManager;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author krish
 */
@WebServlet(name = "OtpServlet", urlPatterns = {"/OtpServlet"})
public class OtpServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            String db = request.getParameter("db");
            String tbl = request.getParameter("tbl");
            String email = request.getParameter("email");
            String pass = request.getParameter("pass");
            String original_otp = request.getParameter("original_otp");
            String user_otp = request.getParameter("otp");
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet OtpServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            
            if(original_otp.equalsIgnoreCase(user_otp))
            {
                String url = "jdbc:mysql://localhost:3306/" + db;
                String sql = "SELECT * FROM "+ tbl +" WHERE email=?";

                try{

                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection(url, "root", "");
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, email);
                    ResultSet rs = ps.executeQuery();

                    

                    if(rs.next())
                    {
                        if((rs.getString("pass")).equals(pass))
                        {
                            String role = rs.getString("role");
                            out.println("<script>alert('"+role+"');</script>");
                            HttpSession session = SessionManager.getInstance().createSession(request);
                            session.setAttribute("Name", rs.getString("name"));
                            session.setAttribute("email", email);
                            
                            RoleStrategy strategy = StrategyFactory.getStrategy(role);
                            RoleContext rc = new RoleContext(strategy);
                            rc.executeStrategy(request, response);
                            
                            out.println("<script>alert('success');</script>");
                        }
                        else
                        {
                            out.println("<script>alert('Invalid Password.');</script>");
                        }
                    }
                    else
                    {
                        out.println("<script>alert('You are not registered.');</script>");
                    }

                    

                    rs.close();
                    ps.close();
                    con.close();
                }catch(SQLException e)
                {
                    out.println("Error: " + e.getMessage());
                } 
            }
            else
            {
                out.println("<form action='LoginServlet' method='post'>"
                            + "You have entered wrong OTP.<br />"
                            + "<button type='submit'>Try Again</button>"
                            + "</form>");

            }
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(OtpServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(OtpServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
