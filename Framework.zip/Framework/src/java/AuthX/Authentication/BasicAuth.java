/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AuthX.Authentication;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 *
 * @author krish
 */
public class BasicAuth implements IAuth{
    
    @Override
    public String createComponent()
    {
        String newf = "";
        String db = "";
        String tbl = "";
        
        newf += "<script>" 
                + "function Validate() {" 
                + "     const email = document.getElementById('email').value;" 
                + "     const password = document.getElementById('password').value;" 
                + "     const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/;" 
                + "     const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/;\n" 
                + "     if (!emailPattern.test(email)) {" 
                + "            alert('Please enter a valid email address.');" 
                + "            return false;" 
                + "     }" 
                + "     if (!passwordPattern.test(password)) {" 
                + "            alert('Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.');" 
                + "            return false;" 
                + "     }" 
                + "     alert('Form submitted successfully!');" 
                + "     return true; "
                + "</script>";
        
        try{
        File file = new File("D:/Framework/Framework/src/java/AuthX/Data.xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document xmlDoc = builder.parse(file);
        xmlDoc.getDocumentElement().normalize();
        
        NodeList dbList = xmlDoc.getElementsByTagName("Database");
        if (dbList.getLength() > 0) {
            db = dbList.item(0).getTextContent().trim();
        }
        
        NodeList tblList = xmlDoc.getElementsByTagName("Table");
        if (tblList.getLength() > 0) {
            tbl = tblList.item(0).getTextContent().trim();
        }
        
        newf = "<form class='form-container' onsubmit='Validate()' action='ValidateServlet?db="+ db +"&tbl="+ tbl +"' method='post'>"
                ;
        
        Element otpElement = (Element) xmlDoc.getElementsByTagName("Login").item(0);

            NodeList otpFields = otpElement.getElementsByTagName("field");

            for (int i = 0; i < otpFields.getLength(); i++) {
                Element field = (Element) otpFields.item(i);
                String type = field.getAttribute("type");
                String value = field.getTextContent().trim();
                
                if(type.equalsIgnoreCase("text") || type.equalsIgnoreCase("number") || type.equalsIgnoreCase("password"))
                {
                    newf += "<div>"
                            + "     <label for='"+ value +"' >"+ value +":</label>" 
                            + "     <input type='"+ type +"' id='"+ value +"' name='"+ value +"'  required/>" 
                            + "</div>";
                }
                if(type.equalsIgnoreCase("select"))
                {
                    String fieldname = field.getAttribute("for").trim();
                    newf += "<div>"
                        + "<label >" + fieldname + ":</label>"
                        + "<select name='" + fieldname + "' id='" + fieldname + "' required>"
                            + "<option value='Select' disabled>Select</option>";
                    NodeList subFields = field.getElementsByTagName("sub-field");
                    
                    for (int j = 0; j < subFields.getLength(); j++) {
                        Element subField = (Element) subFields.item(j);
                        String subValue = subField.getTextContent().trim();
                        newf += "<option value='" + subValue + "'>" + subValue + "</option>";
                    }
                    newf += "</select></div>";
                }
                if(type.equalsIgnoreCase("radio"))
                {
                    String fieldname = field.getAttribute("for").trim();
                    NodeList subFields = field.getElementsByTagName("sub-field");
                    
                    for (int j = 0; j < subFields.getLength(); j++) {
                        Element subField = (Element) subFields.item(j);
                        String subValue = subField.getTextContent().trim();
                        newf += "  <label >"
                            + "    <input type='radio' name='" + fieldname + "' value='" + subValue + "'  required/>"
                            + "    <span >" + subValue + "</span>"
                            + "  </label>";
                    }
                }
                if(type.equalsIgnoreCase("checkbox"))
                {
                    newf += "<div >"
                        + "  <label >"
                        + "    <input type='checkbox' id='" + value + "' name='" + value + "' required  />"
                        + "    <span >" + value + "</span>"
                        + "  </label>"
                        + "</div>";
                }
                
            }
        }catch(Exception e)
        {
            System.out.println("Error: " + e.getMessage());
        }
        
        newf += "<input type='hidden' name='type' value='basic' />"
                + "<br /><button type='submit'>Login</button>" 
                + "</form>";
        
        return newf;
        
    }
}
