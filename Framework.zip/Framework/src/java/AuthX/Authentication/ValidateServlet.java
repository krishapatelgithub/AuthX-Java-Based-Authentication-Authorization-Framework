/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package AuthX.Authentication;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Properties;
import java.util.Random;
import javax.mail.*;
import javax.mail.internet.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.*;
import AuthX.Session.*;

import java.io.File;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import AuthX.Authorization.*;

/**
 *
 * @author krish
 */
@WebServlet(name = "ValidateServlet", urlPatterns = {"/ValidateServlet"})
public class ValidateServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     public static boolean sendEmail(String toEmail, String fromEmail, String password, String otp) {
        // SMTP server configuration
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Authenticator
        Session session = Session.getInstance(props,
            new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(fromEmail, password);
                }
            });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromEmail));
            message.setRecipients(
            Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject("Hello, This Is AuhtX Service Framework.");
            message.setText("Your OTP code is: " + otp);

            Transport.send(message);
            return true;

        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
        }
    }
        

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException, ParserConfigurationException, SAXException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            String OTP_email = "";
            String OTP_pass = "";

            File file = new File("D:/Framework/Framework/src/java/AuthX/Data.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document xmlDoc = builder.parse(file);
            xmlDoc.getDocumentElement().normalize();

            Element otpElement = (Element) xmlDoc.getElementsByTagName("OTP").item(0);

            NodeList otpFields = otpElement.getElementsByTagName("field");

            for (int i = 0; i < otpFields.getLength(); i++) {
                Element field = (Element) otpFields.item(i);
                String type = field.getAttribute("type");
                String value = field.getTextContent().trim();

                if (type.equalsIgnoreCase("email")) {
                    OTP_email = value;
                } else if (type.equalsIgnoreCase("password")) {
                    OTP_pass = value;
                }
            }


            
            
            String db = request.getParameter("db");
            String tbl = request.getParameter("tbl");
            String email = request.getParameter("Email");
            String pass = request.getParameter("Password");
            String type = request.getParameter("type");
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ValidateServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            
            
            if(type.equalsIgnoreCase("mfa"))
            {
                
                String toEmail = email; 
                String fromEmail = OTP_email;
                String password = OTP_pass; 
                

                // Generate 6-digit OTP
                String otp = String.format("%06d", new Random().nextInt(999999));

                // Send the OTP
                boolean result = sendEmail(toEmail, fromEmail, password, otp);

                if (result) {
                    out.println("<script src=\"https://cdn.tailwindcss.com\"></script>\n" 
                    + "<form action='OtpServlet?db="+ db +"&tbl="+ tbl +"&email="+ email +"&pass="+ pass +"&original_otp="+ otp +"' method='post' class='max-w-md mx-auto mt-16 bg-white p-8 rounded-xl shadow-md space-y-6'>" 
                    + "<div>" 
                    + "    <label for='otp' class='block text-gray-700 font-semibold mb-2'>Enter OTP:</label>" 
                    + "    <input type='number' name='otp' id='otp' class='w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500' />" 
                    + "</div>"
                    + "<button type='submit' class='w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200'>Submit</button>" 
                    + "</form>"
                    );
                }
                else {
                    out.println("Failed to send OTP.");
                }
            } 
               
            if(type.equalsIgnoreCase("basic"))
            {
                
                String url = "jdbc:mysql://localhost:3306/" + db;
                String sql = "SELECT * FROM " + tbl + " WHERE email = ?";
                
                try{

                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection(url, "root", "");
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, email);
                    ResultSet rs = ps.executeQuery();

                    

                    if(rs.next())
                    {
                        if((rs.getString("pass")).equals(pass))
                        {
                            String role = rs.getString("role");
                            out.println("<script>alert('"+role+"');</script>");
                            HttpSession session = SessionManager.getInstance().createSession(request);
                            session.setAttribute("Name", rs.getString("name"));
                            session.setAttribute("email", email);
                            
                            RoleStrategy strategy = StrategyFactory.getStrategy(role);
                            RoleContext rc = new RoleContext(strategy);
                            rc.executeStrategy(request, response);
                            
                            out.println("<script>alert('success');</script>");
                        }
                        else
                        {
                            out.println("<script>alert('Invalid Password.');</script>");
                        }
                    }
                    else
                    {
                        out.println("<script>alert('"+ email +"');</script>");
                        out.println("<script>alert('"+ pass +"');</script>");
                    }

                    

                    rs.close();
                    ps.close();
                    con.close();
                }catch(SQLException e)
                {
                    e.printStackTrace();
                    out.println("Error: " + e.getMessage());
                } 
            }
            out.println("</body>");
            out.println("</html>");
            
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
             Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
         } catch (SAXException ex) {
             Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
             Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
         } catch (SAXException ex) {
             Logger.getLogger(ValidateServlet.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
